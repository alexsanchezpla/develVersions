# goProfiles
an R/Bioconductor package for the Statistical Analysis of Functional Profiles
