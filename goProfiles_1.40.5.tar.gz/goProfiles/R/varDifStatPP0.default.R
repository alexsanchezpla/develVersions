`varDifStatPP0.default` <-
function(pn, p0 = NULL, funcProfP0 = NULL, simplify=T) {
  varDifStatPP0.ExpandedGOProfile( as.ExpandedGOProfile(pn), p0, funcProfP0, simplify)
}

