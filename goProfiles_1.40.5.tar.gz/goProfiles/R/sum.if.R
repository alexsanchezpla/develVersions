`sum.if` <-
function(i, logicMat, pGO) {
    return(sum(pGO[logicMat[i,]]))
}

