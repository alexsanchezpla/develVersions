`seDifStatPnQm` <-
function(pn, qm=NULL, pqn0=NULL) {
    return(sqrt(internal.varDifStatPnQm(pn=pn, qm=qm, pqn0=pqn0)))
}

