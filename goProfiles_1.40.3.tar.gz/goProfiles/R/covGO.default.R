`covGO.default` <-
function(pn, simplify=T) {
  covGO.ExpandedGOProfile( as.ExpandedGOProfile(pn), simplify)
}

