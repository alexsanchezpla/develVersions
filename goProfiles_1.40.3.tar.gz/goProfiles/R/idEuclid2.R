`idEuclid2` <-
function(i, X, Y){
        dEuclid2(X[,i], Y[,i])
}

