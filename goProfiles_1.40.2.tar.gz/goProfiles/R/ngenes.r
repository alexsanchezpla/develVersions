`ngenes` <-
function(pn, i=NULL) {
    UseMethod("ngenes")
}

