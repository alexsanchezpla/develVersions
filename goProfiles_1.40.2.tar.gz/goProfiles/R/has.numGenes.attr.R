`has.numGenes.attr` <-
function(obj) !is.null(attr(obj,"numGenes"))

