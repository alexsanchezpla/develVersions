`idEuclid2P0` <-
function(i, X, P){
        dEuclid2(X[,i], P)
}

