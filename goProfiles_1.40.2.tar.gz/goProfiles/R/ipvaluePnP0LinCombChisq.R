`ipvaluePnP0LinCombChisq` <-
function(i, d2, p0, n, sigma, betas)
{
    pvaluePnP0LinCombChisq(d2=d2[i], p0=p0, n=n, sigma=sigma, betas=betas)
}

