#' Ready 2 cluster equivalence distance matrix obtained from the analysis of the "Kidney Dataset" at level 2 of the MF ontology
#'
#' An object of class "list" with the information outputted from of the analysis performed by function "profileEquiv_topDown2"
#' 
"clustKidneyMF2"